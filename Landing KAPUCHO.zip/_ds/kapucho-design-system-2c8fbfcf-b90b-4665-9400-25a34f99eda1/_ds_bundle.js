/* @ds-bundle: {"format":4,"namespace":"KapuchoDesignSystem_2c8fbf","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"WaitlistForm","sourcePath":"components/forms/WaitlistForm.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"9b3a1e684e9f","components/core/Button.jsx":"318994d4ea0b","components/core/Card.jsx":"587b390af648","components/core/Logo.jsx":"53a84de5cf45","components/core/SectionHeading.jsx":"a589dec2e2d4","components/forms/Checkbox.jsx":"b51d28b1ad17","components/forms/Input.jsx":"f6f36c17dca2","components/forms/Select.jsx":"40a23f894f05","components/forms/Textarea.jsx":"3d5530bdff94","components/forms/WaitlistForm.jsx":"7d92fbe866d0","ui_kits/landing/Audiences.jsx":"8e0f13936dbf","ui_kits/landing/Faq.jsx":"75214b3cfc9f","ui_kits/landing/Footer.jsx":"7624f851ff69","ui_kits/landing/Header.jsx":"6639bde975c4","ui_kits/landing/Hero.jsx":"3e2517aea296","ui_kits/landing/HowItWorks.jsx":"abba884ed7c0","ui_kits/landing/WaitlistSection.jsx":"9f5d39f4bb0e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.KapuchoDesignSystem_2c8fbf = window.KapuchoDesignSystem_2c8fbf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
const tones = {
  latte: {
    background: 'var(--surface-latte)',
    color: 'var(--kap-espresso-900)',
    border: 'transparent'
  },
  accent: {
    background: 'var(--surface-accent-soft)',
    color: 'var(--text-accent)',
    border: 'transparent'
  },
  espresso: {
    background: 'var(--surface-inverse)',
    color: 'var(--text-on-inverse)',
    border: 'transparent'
  },
  outline: {
    background: 'transparent',
    color: 'var(--text-body)',
    border: 'var(--border-default)'
  },
  success: {
    background: 'var(--kap-success-bg)',
    color: 'var(--kap-success)',
    border: 'transparent'
  },
  warning: {
    background: 'var(--kap-warning-bg)',
    color: 'var(--kap-warning)',
    border: 'transparent'
  },
  danger: {
    background: 'var(--kap-danger-bg)',
    color: 'var(--kap-danger)',
    border: 'transparent'
  }
};
function Badge({
  tone = 'latte',
  dot = false,
  icon,
  children,
  style
}) {
  const t = tones[tone] || tones.latte;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '7px',
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      background: t.background,
      color: t.color,
      border: '1.5px solid ' + t.border,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'currentColor'
    }
  }), icon, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    padding: '8px 16px',
    fontSize: 'var(--text-body-s)',
    gap: '6px'
  },
  md: {
    padding: '13px 24px',
    fontSize: 'var(--text-body-m)',
    gap: '8px'
  },
  lg: {
    padding: '18px 34px',
    fontSize: 'var(--text-body-l)',
    gap: '10px'
  }
};
const variants = {
  primary: {
    background: 'var(--surface-inverse)',
    color: 'var(--text-on-inverse)',
    border: '1.5px solid var(--surface-inverse)'
  },
  accent: {
    background: 'var(--surface-accent)',
    color: 'var(--text-on-accent)',
    border: '1.5px solid var(--surface-accent)'
  },
  secondary: {
    background: 'transparent',
    color: 'var(--text-body)',
    border: '1.5px solid var(--border-strong)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-body)',
    border: '1.5px solid transparent'
  },
  inverse: {
    background: 'var(--surface-page)',
    color: 'var(--text-heading)',
    border: '1.5px solid var(--surface-page)'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  shape = 'pill',
  stamped = false,
  fullWidth = false,
  disabled = false,
  iconLeft,
  iconRight,
  onClick,
  type = 'button',
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  const radius = shape === 'square' ? 'var(--radius-sm)' : shape === 'block' ? 'var(--radius-none)' : 'var(--radius-pill)';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: fullWidth ? '100%' : 'auto',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '0.01em',
      lineHeight: 1.1,
      cursor: disabled ? 'not-allowed' : 'pointer',
      borderRadius: radius,
      ...v,
      ...s,
      boxShadow: stamped && !disabled ? press ? 'none' : hover ? '6px 6px 0 var(--kap-espresso-900)' : 'var(--shadow-stamp)' : 'none',
      transform: press && !disabled ? stamped ? 'translate(3px,3px)' : 'scale(.98)' : 'none',
      filter: hover && !disabled && !stamped ? 'brightness(1.08)' : 'none',
      opacity: disabled ? 0.4 : 1,
      transition: 'transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), filter var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out)',
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const surfaces = {
  paper: {
    background: 'var(--surface-raised)',
    color: 'var(--text-body)',
    border: '1.5px solid var(--border-hairline)'
  },
  cream: {
    background: 'var(--surface-sunken)',
    color: 'var(--text-body)',
    border: '1.5px solid var(--border-hairline)'
  },
  latte: {
    background: 'var(--surface-latte)',
    color: 'var(--kap-espresso-900)',
    border: '1.5px solid transparent'
  },
  espresso: {
    background: 'var(--surface-inverse)',
    color: 'var(--text-on-inverse)',
    border: '1.5px solid var(--surface-inverse)'
  },
  outline: {
    background: 'transparent',
    color: 'var(--text-body)',
    border: '1.5px solid var(--border-default)'
  }
};
function Card({
  surface = 'paper',
  stamped = false,
  interactive = false,
  padding = 'var(--space-8)',
  radius = 'var(--radius-lg)',
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = surfaces[surface] || surfaces.paper;
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      padding,
      borderRadius: radius,
      ...s,
      boxShadow: stamped ? 'var(--shadow-stamp)' : interactive && hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      transition: 'var(--transition-ui)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
/** Kapucho wordmark. Uses the provided geometric PNG lockup when `src` is
 *  reachable, otherwise falls back to plain display type (never a redrawn mark). */
function Logo({
  height = 28,
  src = 'assets/logo-wordmark.png',
  tone = 'espresso',
  showFallbackText = true,
  style
}) {
  const [failed, setFailed] = React.useState(false);
  if (src && !failed) {
    return /*#__PURE__*/React.createElement("img", {
      src: src,
      alt: "Kapucho",
      onError: () => setFailed(true),
      style: {
        height,
        width: 'auto',
        display: 'block',
        ...style
      }
    });
  }
  if (!showFallbackText) return null;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-black)',
      fontSize: height * 0.86,
      letterSpacing: '0.02em',
      lineHeight: 1,
      textTransform: 'uppercase',
      color: tone === 'cream' ? 'var(--text-on-inverse)' : 'var(--text-heading)',
      ...style
    }
  }, "Kapucho");
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = 'left',
  tone = 'default',
  maxWidth = '620px',
  style
}) {
  const onDark = tone === 'inverse';
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      textAlign: align,
      alignItems: align === 'center' ? 'center' : 'flex-start',
      maxWidth,
      marginInline: align === 'center' ? 'auto' : undefined,
      ...style
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: onDark ? 'var(--kap-terra-300)' : 'var(--text-accent)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-m)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-display)',
      lineHeight: 'var(--lh-snug)',
      margin: 0,
      color: onDark ? 'var(--text-on-inverse)' : 'var(--text-heading)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-l)',
      lineHeight: 'var(--lh-body)',
      color: onDark ? 'var(--text-on-inverse-muted)' : 'var(--text-muted)',
      margin: 0
    }
  }, subtitle));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  description,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  id,
  style
}) {
  const fieldId = id || 'kap-check-' + React.useId();
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const isControlled = checked !== undefined;
  const on = isControlled ? checked : internal;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: fieldId,
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: e => {
      if (!isControlled) setInternal(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: '0 0 auto',
      width: 22,
      height: 22,
      borderRadius: 'var(--radius-xs)',
      border: '1.5px solid ' + (on ? 'var(--kap-espresso-800)' : 'var(--border-default)'),
      background: on ? 'var(--surface-inverse)' : 'var(--surface-raised)',
      display: 'grid',
      placeItems: 'center',
      transition: 'var(--transition-ui)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--kap-cream-100)",
    strokeWidth: "3.2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      lineHeight: 1.45,
      color: 'var(--text-body)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-subtle)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  prefixIcon,
  id,
  type = 'text',
  required = false,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || 'kap-input-' + React.useId();
  const borderColor = error ? 'var(--kap-danger)' : focus ? 'var(--kap-espresso-800)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-body)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-accent)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      background: 'var(--surface-raised)',
      border: '1.5px solid ' + borderColor,
      borderRadius: 'var(--radius-sm)',
      padding: '0 14px',
      boxShadow: focus ? '0 0 0 3px rgba(224,122,79,.28)' : 'var(--shadow-xs)',
      transition: 'var(--transition-ui)'
    }
  }, prefixIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      color: 'var(--text-subtle)'
    }
  }, prefixIcon), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      font: 'inherit',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-m)',
      color: 'var(--text-body)',
      padding: '13px 0',
      minWidth: 0,
      ...style
    }
  }, rest))), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--kap-danger)' : 'var(--text-subtle)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  error,
  id,
  options = [],
  placeholder = 'Elige una opción',
  required = false,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fieldId = id || 'kap-select-' + React.useId();
  const borderColor = error ? 'var(--kap-danger)' : focus ? 'var(--kap-espresso-800)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-body)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-accent)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      width: '100%',
      background: 'var(--surface-raised)',
      border: '1.5px solid ' + borderColor,
      borderRadius: 'var(--radius-sm)',
      padding: '13px 40px 13px 14px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-m)',
      color: 'var(--text-body)',
      outline: 'none',
      cursor: 'pointer',
      boxShadow: focus ? '0 0 0 3px rgba(224,122,79,.28)' : 'var(--shadow-xs)',
      transition: 'var(--transition-ui)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const value = typeof o === 'string' ? o : o.value;
    const labelText = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, labelText);
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      right: 14,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-subtle)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  })))), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--kap-danger)' : 'var(--text-subtle)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label,
  hint,
  error,
  id,
  rows = 4,
  required = false,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fieldId = id || 'kap-textarea-' + React.useId();
  const borderColor = error ? 'var(--kap-danger)' : focus ? 'var(--kap-espresso-800)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-body)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-accent)'
    }
  }, " *")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: fieldId,
    rows: rows,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      background: 'var(--surface-raised)',
      border: '1.5px solid ' + borderColor,
      borderRadius: 'var(--radius-sm)',
      padding: '13px 14px',
      resize: 'vertical',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-m)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-body)',
      outline: 'none',
      boxShadow: focus ? '0 0 0 3px rgba(224,122,79,.28)' : 'var(--shadow-xs)',
      transition: 'var(--transition-ui)',
      ...style
    }
  }, rest)), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--kap-danger)' : 'var(--text-subtle)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/forms/WaitlistForm.jsx
try { (() => {
/** The validation-page signup panel: name, email, phone, role, city, consent. */
function WaitlistForm({
  title = 'Entra en la lista',
  subtitle = 'Te escribimos una sola vez: el día que abrimos en tu ciudad.',
  roleOptions = [{
    value: 'barista',
    label: 'Barista'
  }, {
    value: 'cafeteria',
    label: 'Cafetería'
  }],
  cityOptions = ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Bilbao', 'Otra'],
  onSubmit,
  compact = false,
  style
}) {
  const [values, setValues] = React.useState({
    name: '',
    email: '',
    phone: '',
    role: '',
    city: '',
    consent: false
  });
  const [errors, setErrors] = React.useState({});
  const [sent, setSent] = React.useState(false);
  const set = k => e => setValues(v => ({
    ...v,
    [k]: k === 'consent' ? e.target.checked : e.target.value
  }));
  const submit = e => {
    e.preventDefault();
    const next = {};
    if (!values.name.trim()) next.name = 'Dinos cómo te llamamos.';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(values.email)) next.email = 'Necesitamos un correo válido.';
    if (values.phone.replace(/[^0-9]/g, '').length < 9) next.phone = 'Necesitamos un teléfono válido.';
    if (!values.role) next.role = 'Elige una opción.';
    if (!values.consent) next.consent = true;
    setErrors(next);
    if (Object.keys(next).length === 0) {
      setSent(true);
      onSubmit && onSubmit(values);
    }
  };
  if (sent) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-4)',
        alignItems: 'flex-start',
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 52,
        height: 52,
        borderRadius: '50%',
        background: 'var(--surface-accent)',
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "26",
      height: "26",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "2.6",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M20 6 9 17l-5-5"
    }))), /*#__PURE__*/React.createElement("h3", {
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-heading-m)',
        color: 'var(--text-heading)',
        margin: 0
      }
    }, "Est\xE1s dentro, ", values.name.split(' ')[0], "."), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-sans)',
        color: 'var(--text-muted)',
        margin: 0
      }
    }, "Te avisamos por correo el d\xEDa del lanzamiento. Nada m\xE1s."));
  }
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    noValidate: true,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-m)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-heading)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-muted)',
      margin: 0
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: compact ? '1fr' : '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Input, {
    label: "Nombre",
    placeholder: "Marta Ruiz",
    value: values.name,
    onChange: set('name'),
    error: errors.name,
    required: true
  }), /*#__PURE__*/React.createElement(__ds_scope.Input, {
    label: "Correo",
    type: "email",
    placeholder: "marta@cafeteria.es",
    value: values.email,
    onChange: set('email'),
    error: errors.email,
    required: true
  }), /*#__PURE__*/React.createElement(__ds_scope.Input, {
    label: "Tel\xE9fono",
    type: "tel",
    placeholder: "+34 600 000 000",
    hint: "Para avisarte por WhatsApp.",
    value: values.phone,
    onChange: set('phone'),
    error: errors.phone,
    required: true
  }), /*#__PURE__*/React.createElement(__ds_scope.Select, {
    label: "\xBFQui\xE9n eres?",
    options: roleOptions,
    value: values.role,
    onChange: set('role'),
    error: errors.role,
    required: true
  }), /*#__PURE__*/React.createElement(__ds_scope.Select, {
    label: "Ciudad",
    options: cityOptions,
    value: values.city,
    onChange: set('city'),
    placeholder: "\xBFD\xF3nde tomas caf\xE9?",
    wrapperStyle: {
      gridColumn: compact ? 'auto' : '1 / -1'
    }
  })), /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    label: "Quiero recibir un correo cuando Kapucho abra en mi ciudad.",
    checked: values.consent,
    onChange: set('consent'),
    style: errors.consent ? {
      color: 'var(--kap-danger)'
    } : undefined
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    type: "submit",
    variant: "accent",
    size: "lg",
    fullWidth: true
  }, "Av\xEDsame del lanzamiento"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-subtle)'
    }
  }, "Cero spam. Puedes salirte con un clic."));
}
Object.assign(__ds_scope, { WaitlistForm });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/WaitlistForm.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/Audiences.jsx
try { (() => {
const {
  Card,
  SectionHeading,
  Button
} = window.KapuchoDesignSystem_2c8fbf;
function Check() {
  return /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.6",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flex: '0 0 auto',
      marginTop: 3
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }));
}
function List({
  items,
  tone
}) {
  return /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, items.map(i => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-m)',
      lineHeight: 'var(--lh-body)',
      color: tone === 'inverse' ? 'var(--text-on-inverse)' : 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: tone === 'inverse' ? 'var(--kap-terra-300)' : 'var(--text-accent)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Check, null)), i)));
}
function Audiences({
  onCta
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--section-y) var(--gutter)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Para qui\xE9n",
    title: "Dos lados de la misma barra",
    subtitle: "Kapucho solo funciona si funciona para los dos."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,minmax(0,1fr))',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    surface: "paper",
    padding: "var(--space-8)",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '100% 0 0 0',
      background: 'var(--kap-latte-400)'
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-l)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-heading)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, "Baristas"), /*#__PURE__*/React.createElement(List, {
    items: ['Turnos sueltos que encajan con tu semana', 'Tarifa clara antes de aceptar', 'Cafeterías de especialidad, no cadenas', 'Tu perfil, tus técnicas, tus certificados']
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onCta,
    style: {
      alignSelf: 'flex-start'
    }
  }, "Quiero turnos")), /*#__PURE__*/React.createElement(Card, {
    surface: "espresso",
    padding: "var(--space-8)",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '0 0 100% 0',
      background: 'var(--kap-terra-500)'
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-l)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-heading)',
      color: 'var(--text-on-inverse)',
      margin: 0
    }
  }, "Cafeter\xEDas"), /*#__PURE__*/React.createElement(List, {
    tone: "inverse",
    items: ['Cubres una baja en minutos, no en días', 'Perfiles verificados y valorados', 'Sin comisión de agencia', 'Historial: repites con quien ya funcionó']
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    onClick: onCta,
    style: {
      alignSelf: 'flex-start'
    }
  }, "Necesito baristas"))));
}
Object.assign(window, {
  Audiences
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/Audiences.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/Faq.jsx
try { (() => {
const {
  SectionHeading
} = window.KapuchoDesignSystem_2c8fbf;
const kapFaqs = [{
  q: '¿Cuándo abre Kapucho?',
  a: 'Estamos validando la idea. Si la respuesta acompaña, la primera versión llega en otoño de 2026, empezando por Madrid.'
}, {
  q: '¿Cuesta algo apuntarse?',
  a: 'No. La lista es gratis y no reserva nada más que tu aviso de lanzamiento.'
}, {
  q: '¿Qué hacéis con mis datos?',
  a: 'Un correo cuando abrimos y, si nos lo permites, alguna pregunta corta para diseñar la app. Nada más, y te puedes borrar con un clic.'
}, {
  q: 'Soy cafetería, ¿puedo probarlo antes?',
  a: 'Sí. Marca "Tengo una cafetería" y entras en el grupo de pruebas privadas.'
}];
function Faq() {
  const [open, setOpen] = React.useState(0);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-narrow)',
      margin: '0 auto',
      padding: 'var(--section-y) var(--gutter)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Preguntas",
    title: "Lo que nos preguntan siempre"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, kapFaqs.map((f, i) => {
    const isOpen = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: f.q,
      style: {
        borderTop: '1.5px solid var(--border-hairline)',
        borderBottom: i === kapFaqs.length - 1 ? '1.5px solid var(--border-hairline)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpen(isOpen ? -1 : i),
      style: {
        width: '100%',
        background: 'none',
        border: 'none',
        padding: 'var(--space-5) 0',
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-4)',
        cursor: 'pointer',
        textAlign: 'left'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--text-heading-s)',
        fontWeight: 'var(--fw-semibold)',
        color: 'var(--text-heading)'
      }
    }, f.q), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        color: 'var(--text-accent)',
        transform: isOpen ? 'rotate(45deg)' : 'none',
        transition: 'transform var(--dur-base) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "18",
      height: "18",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.4",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M12 5v14M5 12h14"
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        maxHeight: isOpen ? 200 : 0,
        overflow: 'hidden',
        transition: 'max-height var(--dur-slow) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-body-m)',
        lineHeight: 'var(--lh-relaxed)',
        color: 'var(--text-muted)',
        margin: 0,
        paddingBottom: 'var(--space-5)',
        maxWidth: 560
      }
    }, f.a)));
  })));
}
Object.assign(window, {
  Faq
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/Faq.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/Footer.jsx
try { (() => {
const {
  Logo,
  Button
} = window.KapuchoDesignSystem_2c8fbf;
function Footer({
  onCta
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-sunken)',
      borderTop: '1.5px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--space-12) var(--gutter)',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-8)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 24,
    src: "../../assets/logo-wordmark.png"
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      flexWrap: 'wrap'
    }
  }, ['Privacidad', 'Aviso legal', 'hola@kapucho.app'].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#top",
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-muted)',
      borderBottom: 'none'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-subtle)'
    }
  }, "\xA9 2026 Kapucho \xB7 Madrid"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onCta
  }, "Entrar en la lista"))));
}
Object.assign(window, {
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/Header.jsx
try { (() => {
const {
  Button,
  Logo
} = window.KapuchoDesignSystem_2c8fbf;
function Header({
  onCta
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const el = document.getElementById('kap-scroll');
    if (!el) return;
    const fn = () => setScrolled(el.scrollTop > 12);
    el.addEventListener('scroll', fn);
    return () => el.removeEventListener('scroll', fn);
  }, []);
  const links = ['Cómo funciona', 'Para baristas', 'Para cafeterías', 'Preguntas'];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      background: scrolled ? 'rgba(247,239,229,.86)' : 'transparent',
      backdropFilter: scrolled ? 'blur(10px)' : 'none',
      borderBottom: '1.5px solid ' + (scrolled ? 'var(--border-hairline)' : 'transparent'),
      transition: 'var(--transition-ui)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '18px var(--gutter)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      borderBottom: 'none',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 26,
    src: "../../assets/logo-wordmark.png"
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      marginLeft: 'auto'
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#top",
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-body)',
      borderBottom: 'none'
    }
  }, l))), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "sm",
    onClick: onCta
  }, "Entrar en la lista")));
}
Object.assign(window, {
  Header
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/Hero.jsx
try { (() => {
const {
  Button,
  Badge
} = window.KapuchoDesignSystem_2c8fbf;
function ShapeStack() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gridTemplateRows: '1fr 1fr',
      gap: 12,
      aspectRatio: '1 / 1',
      width: '100%',
      maxWidth: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--kap-espresso-800)',
      borderRadius: '100% 0 0 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--kap-latte-400)',
      borderRadius: 'var(--radius-md)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--kap-cream-200)',
      borderRadius: 'var(--radius-md)',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '46%',
      aspectRatio: '1',
      borderRadius: '50%',
      background: 'var(--kap-terra-500)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--kap-latte-300)',
      borderRadius: '0 0 100% 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeItems: 'center',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-raised)',
      boxShadow: 'var(--shadow-lg)',
      borderRadius: 'var(--radius-md)',
      padding: '14px 18px',
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      background: 'var(--kap-espresso-800)',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--kap-cream-100)',
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 14
    }
  }, "M"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 15,
      color: 'var(--text-heading)'
    }
  }, "Turno cubierto en 7 min"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--text-subtle)'
    }
  }, "Caf\xE9 Mercado \xB7 s\xE1bado 8:00")))));
}
function Hero({
  onCta
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'clamp(32px,5vw,64px) var(--gutter) var(--section-y)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.05fr) minmax(0,.95fr)',
      gap: 'clamp(32px,6vw,80px)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    dot: true
  }, "Lista de espera abierta"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-xl)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-display)',
      lineHeight: 'var(--lh-tight)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, "Baristas y cafeter\xEDas de especialidad, en minutos."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-l)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-muted)',
      maxWidth: 520,
      margin: 0
    }
  }, "Kapucho cubre el turno que se te acaba de caer. Publicas, ves qui\xE9n est\xE1 cerca y cierras \u2014 sin agencias ni cadenas de WhatsApp."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    stamped: true,
    onClick: onCta
  }, "Av\xEDsame del lanzamiento"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: onCta
  }, "Soy cafeter\xEDa")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex'
    }
  }, ['#4B2E20', '#D6BEA5', '#E07A4F', '#8A6A55'].map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      width: 26,
      height: 26,
      borderRadius: '50%',
      background: c,
      border: '2px solid var(--surface-page)',
      marginLeft: i ? -9 : 0
    }
  }))), "412 personas ya est\xE1n en la lista")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(ShapeStack, null)));
}
Object.assign(window, {
  Hero,
  ShapeStack
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/HowItWorks.jsx
try { (() => {
const {
  Card,
  SectionHeading,
  Badge
} = window.KapuchoDesignSystem_2c8fbf;
const kapSteps = [{
  n: '01',
  t: 'Publica el turno',
  d: 'Día, hora, tipo de café y qué necesitas saber hacer. Treinta segundos.'
}, {
  n: '02',
  t: 'Recibe perfiles cerca',
  d: 'Baristas verificados de tu zona, con experiencia y disponibilidad real.'
}, {
  n: '03',
  t: 'Cierra y a servir',
  d: 'Confirmas en la app, el barista llega y el turno queda cubierto.'
}];
function HowItWorks() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-sunken)',
      borderBlock: '1.5px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--section-y) var(--gutter)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "C\xF3mo funciona",
    title: "Tres pasos y el turno est\xE1 cubierto",
    subtitle: "Sin llamadas, sin CVs en PDF, sin comisiones de agencia."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,minmax(0,1fr))',
      gap: 'var(--space-5)'
    }
  }, kapSteps.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.n,
    surface: "paper",
    interactive: true,
    padding: "var(--space-6)",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-accent)',
      fontWeight: 500
    }
  }, s.n), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-m)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-heading)',
      margin: 0
    }
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-m)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-muted)',
      margin: 0
    }
  }, s.d)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "outline"
  }, "Madrid"), /*#__PURE__*/React.createElement(Badge, {
    tone: "outline"
  }, "Barcelona"), /*#__PURE__*/React.createElement(Badge, {
    tone: "outline"
  }, "Valencia"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-subtle)'
    }
  }, "Primeras ciudades al abrir. Dinos la tuya en el formulario."))));
}
Object.assign(window, {
  HowItWorks
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/HowItWorks.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/WaitlistSection.jsx
try { (() => {
const {
  Card,
  WaitlistForm,
  Badge
} = window.KapuchoDesignSystem_2c8fbf;
function WaitlistSection({
  formRef,
  onSubmit
}) {
  return /*#__PURE__*/React.createElement("section", {
    ref: formRef,
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--section-y) var(--gutter)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,.9fr) minmax(0,1.1fr)',
      gap: 'clamp(32px,6vw,72px)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "accent"
  }, "Antes de construirla"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-l)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-display)',
      lineHeight: 'var(--lh-snug)',
      color: 'var(--text-on-inverse)',
      margin: 0
    }
  }, "D\xE9janos tus datos y te avisamos el primer d\xEDa."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-l)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-on-inverse-muted)',
      margin: 0,
      maxWidth: 420
    }
  }, "Estamos validando la idea con baristas y cafeter\xEDas reales. Si te apuntas, decides qu\xE9 construimos primero."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-8)',
      paddingTop: 'var(--space-2)'
    }
  }, [['412', 'en la lista'], ['38', 'cafeterías'], ['3', 'ciudades']].map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-l)',
      fontWeight: 'var(--fw-bold)',
      color: 'var(--kap-terra-300)'
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-s)',
      color: 'var(--text-on-inverse-muted)'
    }
  }, l))))), /*#__PURE__*/React.createElement(Card, {
    surface: "paper",
    padding: "clamp(24px,3vw,36px)",
    radius: "var(--radius-lg)",
    style: {
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement(WaitlistForm, {
    onSubmit: onSubmit
  }))));
}
Object.assign(window, {
  WaitlistSection
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/WaitlistSection.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.WaitlistForm = __ds_scope.WaitlistForm;

})();
