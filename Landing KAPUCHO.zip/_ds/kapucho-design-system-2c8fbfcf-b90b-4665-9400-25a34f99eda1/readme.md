# Kapucho — Design System

**Kapucho** is a pre-launch Spanish marketplace app that will connect **baristas** with
**specialty coffee shops in a matter of minutes**: a café publishes a shift, nearby verified
baristas show up as profiles, the shift gets covered — no agencies, no WhatsApp chains.

The app is not built yet. The one live surface is a **Spanish-language validation landing page**
whose only job is to collect emails / phone numbers from future users who want to be told
when the app launches. This design system exists to make that page — and everything after it —
look like one brand.

## Sources given
- `uploads/ChatGPT Image 29 jul 2026, 11_24_16.png` — the KAPUCHO geometric wordmark (also copied, trimmed and background-removed, to `assets/logo-wordmark.png`). Generated art supplied by the founder; it is the only brand asset that exists.
- Palette supplied verbatim by the founder: `#F7EFE5`, `#D6BEA5`, primary `#4B2E20`, accent `#E07A4F`.
- No codebase, Figma file, deck, font binaries or photography were provided. Everything else here is derived from those two inputs; anything derived is flagged below.

---

## Index
| Path | What it is |
|---|---|
| `styles.css` | The single entry point consumers link. `@import`s only. |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `elevation.css`, `motion.css`, `base.css` |
| `components/core/` | Button, Logo, Badge, Card, SectionHeading |
| `components/forms/` | Input, Textarea, Select, Checkbox, WaitlistForm |
| `guidelines/` | Foundation specimen cards (Colors, Type, Spacing, Brand) |
| `ui_kits/landing/` | Full click-through recreation of the validation landing page |
| `templates/landing-page/` | Copyable landing-page starting folder (Design Component) |
| `assets/` | `logo-wordmark.png`, `logo-wordmark-cream.png` |
| `thumbnail.html` | Homepage tile |
| `SKILL.md` | Agent-Skills wrapper so this folder works inside Claude Code |

### Components
Every component is `<Name>.jsx` + `<Name>.d.ts` + `<Name>.prompt.md`, exported on the compiled bundle namespace.

- **Button** — espresso / terracotta / outline / ghost / inverse, 3 sizes, optional hard "stamp" shadow
- **Logo** — the wordmark lockup, degrades to plain uppercase Outfit type
- **Badge** — uppercase status and eyebrow pills
- **Card** — paper / cream / latte / espresso / outline surfaces
- **SectionHeading** — eyebrow + display title + lead
- **Input** — labelled text/email/tel field with hint and error states
- **Textarea** — optional open answers
- **Select** — native select, chevron, 2–6 options
- **Checkbox** — espresso-filled consent / multi-select
- **WaitlistForm** — the whole signup panel with validation + success state

#### Intentional additions
- **WaitlistForm** — no source defined it, but it is the entire point of the current product surface, so it is packaged as one primitive instead of being re-assembled on every page.
- **Logo** — wraps the supplied PNG so nobody is tempted to redraw the geometric letterforms.

---

## CONTENT FUNDAMENTALS

**Language.** Spanish (Spain), always. `tú`, never `usted`. Speak as *nosotros* about the company
("te avisamos", "estamos validando la idea"), address the reader as *tú* ("dinos tu ciudad").

**Register.** Barra de bar, not boardroom. Short declaratives, coffee-trade vocabulary
(*turno, barra, extracción, especialidad, cubrir una baja*). It is fine to be blunt about being
early-stage — honesty is the conversion argument here.

**Casing.** Sentence case everywhere: headlines, buttons, labels, nav. UPPERCASE only in badges,
eyebrows and the wordmark. Never Title Case A Sentence Like This.

**Length.** Headline ≤ 8 words. Lead ≤ 28 words. Button labels 2–4 words and always a verb
("Avísame del lanzamiento", "Entrar en la lista", "Necesito baristas"). Form hints one line, and
they justify the ask ("Solo para avisarte del lanzamiento").

**Punctuation.** Periods in prose, none in headlines that already end a thought, no exclamation
marks, no ellipses. Numerals as digits ("7 min", "412 personas"). Spanish opens questions with `¿`.

**Yes / no examples**
- ✅ "Baristas y cafeterías de especialidad, en minutos."  ❌ "La Plataforma Líder De Talento Hostelero"
- ✅ "Cero spam. Puedes salirte con un clic."  ❌ "¡No te pierdas nuestras increíbles novedades!"
- ✅ "Estamos validando la idea con baristas reales."  ❌ "Revolucionamos el sector del café ☕🚀"

**Emoji: never.** Not in copy, not in cards, not in buttons. The geometric shape kit carries the
personality instead.

---

## VISUAL FOUNDATIONS

**Colour.** A single warm coffee ramp — cream `#F7EFE5` (page), latte `#D6BEA5` (secondary surface,
borders), espresso `#4B2E20` (primary, type, dark bands) — plus terracotta `#E07A4F` as the only
saturated colour. **There is no grey in this system**; every neutral is warm. Terracotta is rationed:
one accent-filled CTA per view, plus eyebrows and small marks. Max two background tones per page
(cream + one espresso band). Status colours are muted and in-family (olive success, ochre warning,
brick danger) — never neon.

**Type.** Display = **Outfit** (geometric grotesk; its circles and flat terminals echo the wordmark),
bold/extrabold, tracking `-0.03em`, line-height 0.98–1.12 — headlines are set tight and large
(hero up to 88px). Body = **Manrope**, 16/19px, line-height 1.6, regular–semibold. Mono =
**IBM Plex Mono**, used only for step numbers, tokens and code. Eyebrows: 12px, uppercase,
`0.16em` tracking, terracotta. ⚠️ **No font files were provided — all three are Google Fonts substitutions.**

**Backgrounds.** Flat colour fields. No gradients, no noise overlays, no photographic hero.
Sections alternate cream → sunken cream (`#F0E4D4`) → espresso, separated by 1.5px hairlines
(`rgba(75,46,32,.12)`) rather than heavy rules.

**Imagery.** None supplied. The brand's visual language is instead a **flat geometric shape kit
lifted from the wordmark**: quarter-circles, half-circles, triangles, blocks and rings, in solid
brand colours, 1–2 per section, freely rotated. When real photography arrives it should be warm,
slightly grainy, low-contrast, shot in daylight on a bar — never cool, never blue-toned, never
stock-office. Never redraw the logo or invent illustration.

**Corners.** 6px (checkboxes, small chips), 10px (inputs), 16px (small cards), 24px (major cards),
32px (large panels), and full pills for every button. Shape-kit elements use 100%/0 corner pairs to
make quarter-circles.

**Cards.** Paper (`#FFFDFA`) or latte fill, 1.5px hairline border, 24px radius, 24–32px padding,
`--shadow-xs` at rest. Interactive cards lift 2px into `--shadow-md` on hover. One espresso card
per section maximum, as emphasis. No coloured left borders.

**Shadows.** Two systems. (1) Soft, always brown-tinted (`rgba(53,32,22,…)`), never black:
xs → lg for surfaces and the form panel. (2) The signature **stamp** — a 4px hard offset espresso
block with zero blur, used on hero CTAs and anchor cards; on hover it grows to 6px, on press the
element travels 3px into it and the shadow disappears. Inner shadow is only ever the
`--shadow-inset-hairline` used to outline swatches.

**Borders.** 1.5px is the brand's line weight (2px only for emphasis). Hairline `12%` espresso for
dividers, `22%` for form fields, solid espresso for outline buttons.

**Motion.** Ease-out `cubic-bezier(.2,.7,.25,1)` for everything; 120ms for presses, 200ms for
hover/state, 420ms for reveals and accordions. Fades and short 2–8px translations only —
**no bounce, no spring, no parallax, no scroll-jacking, no looping background animation.**

**States.** Hover: filled buttons brighten ~8%; stamped buttons deepen their offset; cards lift;
links shift terracotta 500 → 700. Press: `scale(.98)` (or travel-into-stamp), 120ms. Focus:
2.5px terracotta ring, 2px offset; form fields also get a 3px `rgba(224,122,79,.28)` halo and an
espresso border. Disabled: 40% opacity, no shadow, `not-allowed`.

**Transparency & blur.** Almost never. The one sanctioned use is the sticky header, which after
12px of scroll becomes `rgba(247,239,229,.86)` + `blur(10px)` + hairline. No glassmorphism panels,
no protection gradients over imagery — capsules and solid fills instead.

**Layout.** 1160px max container, 680px narrow column for forms and prose, fluid gutter
`clamp(20px,5vw,64px)`, vertical section rhythm `clamp(64px,9vw,128px)`. Two-column hero
(≈1.05fr / 0.95fr), 3-up feature grid, 2-up audience grid. The header is the only fixed element;
CTAs scroll to the form rather than opening modals. 4px spacing base (4→128).

---

## ICONOGRAPHY

- No icon set, icon font, or SVG assets were provided with the brand.
- **Substitution (flagged):** iconography follows **Lucide** — 24×24 grid, 2px–2.6px round-cap
  round-join strokes, no fills. The handful of glyphs used in components (check, chevron-down,
  plus) are inlined as Lucide-shaped paths so components stay dependency-free; for anything richer,
  load Lucide from CDN: `<script src="https://unpkg.com/lucide@latest"></script>` and use
  `data-lucide="coffee"`, then `lucide.createIcons()`.
- Stroke icons only, `currentColor`, 18–24px, never duotone, never filled-and-stroked.
- **No emoji, ever**, and no unicode pictographs used as icons. The only non-icon glyph in use is
  the arrow `→` inside "next" buttons, set in the mono face.
- Brand-shaped "icons" — the quarter-circle / triangle / ring blocks — are decorative, not
  interactive, and are never mixed into an icon row with Lucide strokes.
- Please send a real icon set if one exists; the Lucide choice is a placeholder decision.

---

## Known gaps / to confirm
1. **Fonts** — Outfit + Manrope + IBM Plex Mono are our picks, not yours. Send real files if the brand has them.
2. **Photography** — none exists; the shape kit stands in.
3. **Copy numbers** (412 signups, 38 cafés, 3 cities) in the UI kit are placeholders.
4. **Logo** — only a raster PNG exists. A vector (SVG) wordmark would be worth commissioning.
